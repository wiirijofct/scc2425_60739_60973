package scc.utils;

import java.util.Locale;

import com.azure.cosmos.models.CosmosItemResponse;
import com.azure.cosmos.util.CosmosPagedIterable;

import scc.data.User;
import scc.data.UserDAO;
import scc.db.CosmosDBLayer;

/**
 * Standalone program for accessing the database
 *
 */
public class TestUsers
{
	public static void main(String[] args) {
		System.setProperty(org.slf4j.simple.SimpleLogger.DEFAULT_LOG_LEVEL_KEY, "Error");

		try {
			Locale.setDefault(Locale.US);
			CosmosDBLayer db = CosmosDBLayer.getInstance();
					
			var id = "john";
			
			var user = new User(id, "12345", "john@nova.pt", "John Smith");
			
			var res1 = db.insertOne( user);
			System.out.println( res1 );
			
			var res2 = db.getOne(id, UserDAO.class);
			System.out.println( res2 );
			
			var res3 = db.getOne(id, User.class);
			System.out.println( res3 );

			System.out.println( "Get for id = " + id);
			var res4 = db.query(User.class, String.format("SELECT * FROM users WHERE users.id=\"%s\"", id));
			System.out.println( res4 );
			
			System.out.println( "Get for all ids");
			var res5 = db.query(User.class, "SELECT * FROM users");
			System.out.println( res5);
			
		} catch( Exception x ) {
			x.printStackTrace();
		}
	}
		
}


